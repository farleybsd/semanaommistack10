# DEV-RADAR

Esta aplicação desenvolvida em NodeJS, ReactJS e React Nativa, foi realizada através da semana omnistack 10 da rocketseat.

## FEATURES

Contudo, funcionalidades mais foram desenvolvidas além do conteudo apresentado.

* em desenvolvimento ainda...